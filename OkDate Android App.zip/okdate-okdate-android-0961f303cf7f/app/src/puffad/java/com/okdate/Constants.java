package com.okdate;

public class Constants
{
    public static final String PARSE_APPLICATION_ID = "ZtrXRg4aAqBttDrTew2aNdKKVE21usgmu2EngydZ";
    public static final String PARSE_CLIENT_KEY = "3uTUkk2DU9ZtE0mc07zoKplLgwbymMXsYokXEd33";
}
