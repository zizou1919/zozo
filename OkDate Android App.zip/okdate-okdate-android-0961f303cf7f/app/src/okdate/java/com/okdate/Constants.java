package com.okdate;

/**
 * Created by Mehshan on 2/18/2016.
 */
public class Constants
{
    public static final String PARSE_APPLICATION_ID = "AaBH3r02U7ltlVznSPlORQO5BDy6ryCxbOBMb5Nz";
    public static final String PARSE_CLIENT_KEY = "VjYD38YoPjjalFgFKHxiEOtDtz9HEBz08xSKKLrU";
}
