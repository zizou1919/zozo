package com.okdate;

/**
 * Created by Mehshan on 2/18/2016.
 */
public class Constants
{
    public static final String PARSE_APPLICATION_ID = "UaDExdJwhxzy4YHg4TTGvzo5JRt7ZtsTe3B1gEHB";
    public static final String PARSE_CLIENT_KEY = "VWLMEaqVwTt6TMdL7qDzXBOpBURRykBqNcREFAhz";
}
