package com.okdate;

import android.app.Application;

import com.parse.Parse;

public class OkDateApplication extends Application
{
    @Override
    public void onCreate()
    {
        super.onCreate();

        Parse.initialize(this, Constants.PARSE_APPLICATION_ID, Constants.PARSE_CLIENT_KEY);
    }
}
