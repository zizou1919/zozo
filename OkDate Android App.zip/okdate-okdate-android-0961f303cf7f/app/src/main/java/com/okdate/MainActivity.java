package com.okdate;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;

import com.parse.ParseException;
import com.parse.ParseInstallation;
import com.parse.SaveCallback;

import org.apache.cordova.CordovaActivity;

public class MainActivity extends CordovaActivity
{
    private static final String TAG = MainActivity.class.getSimpleName();

    private String mFailingUrl;

    private FrameLayout mContentLayout;
    private View mErrorView;

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        Log.d(TAG, "onCreate");

        super.onCreate(savedInstanceState);

        final ParseInstallation installation = ParseInstallation.getCurrentInstallation();

        installation.saveInBackground(new SaveCallback()
        {
            @Override
            public void done(ParseException exception)
            {
                String url = launchUrl;

                if (exception == null)
                {
                    url = launchUrl + "?installation=" + installation.getObjectId();
                }

                Log.d(TAG, "onCreate.done: exception = " + exception + ", url = " + url);

                loadUrl(url);
                setContentView(R.layout.content);

                mContentLayout = (FrameLayout) findViewById(R.id.content);
                mContentLayout.addView(appView.getView());

                mErrorView = getLayoutInflater().inflate(R.layout.error, null);
                mErrorView.setVisibility(View.GONE);
                mErrorView.findViewById(R.id.retryButton).setOnClickListener(new View.OnClickListener()
                {
                    @Override
                    public void onClick(View view)
                    {
                        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

                        if (connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED)
                        {
                            loadUrl(mFailingUrl);

                            mErrorView.setVisibility(View.GONE);
                            appView.getView().setVisibility(View.VISIBLE);
                        }
                    }
                });

                mContentLayout.addView(mErrorView);
            }
        });
    }

    @Override
    public void onReceivedError(int errorCode, String description, String failingUrl)
    {
        Log.d(TAG, "onReceivedError: errorCode =" + errorCode + ", " + description);

        mFailingUrl = failingUrl;

        appView.getView().setVisibility(View.GONE);
        mErrorView.setVisibility(View.VISIBLE);

        loadUrl("file:///android_asset/www/error.html");

        super.onReceivedError(errorCode, description, failingUrl);
    }

    @Override
    public void displayError(String title, String message, String button, boolean exit)
    {
        Log.d(TAG, "displayError: title = " + title + ", message = " + message + ", exit = " + exit);
    }
}
